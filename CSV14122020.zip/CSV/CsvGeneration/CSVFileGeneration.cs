﻿
using CSV.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using MySql.Data.MySqlClient;
using Serilog;
using System;
using System.Configuration;
using System.Data;
using System.Data.Odbc;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace CSV.CsvGeneration
{
    public class CSVFileGeneration
    {
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<Worker> _logger;
        public CSVFileGeneration(IConfiguration iconfiguration, ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<Worker>();
            _iconfiguration = iconfiguration;
             CsvGeneration();
             Download_File();
             Upload_CSVtoMySql();
             
        }
        public void CsvGeneration()
        {
            var logpath = _iconfiguration.GetSection("Path_Information").GetSection("LogPath").Value;
            Log.Logger = new LoggerConfiguration().WriteTo.File(logpath).CreateLogger();
            Log.Information("sample information");
            var Con = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("MySql_Connection").Value;
            string selectQuery = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("Querystring").Value;
            var table = ReadTable(Con, selectQuery);
            var path = _iconfiguration.GetSection("Path_Information").GetSection("Path").Value;
            WriteToFile(table, path, false, ", ");
        }
        public static DataTable ReadTable(string connectionString, string selectQuery)
        {
            var returnValue = new DataTable();
            var conn = new MySqlConnection(connectionString);
            try
            {
                conn.Open();
                var command = new MySqlCommand(selectQuery, conn);
                using (var adapter = new MySqlDataAdapter(command))
                {
                    adapter.Fill(returnValue);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error Message");
                throw ex;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
            return returnValue;
        }
        public static void WriteToFile(DataTable dataSource, string fileOutputPath, bool firstRowIsColumnHeader = false, string seperator = ";")
        {
            try
            {
                var sw = new StreamWriter(fileOutputPath, false);
                int icolcount = dataSource.Columns.Count;
                //var tcname = dataSource.Columns.Add("RT_Processed_Date");
                //var tcname1 = dataSource.Columns.Add("Status");
                if (!firstRowIsColumnHeader)
                {
                    int data = dataSource.Columns.Count;
                    for (int i = 0; i < data; i++)
                    {
                        sw.Write(dataSource.Columns[i]);
                        if (i < data - 1)
                            sw.Write(seperator);
                    }
                    sw.Write(sw.NewLine);
                }
                foreach (DataRow drow in dataSource.Rows)
                {
                    int data = dataSource.Columns.Count;

                    for (int i = 0; i < data; i++)
                    {
                        //if (drow[10] == null || drow[10].ToString() == string.Empty)
                        //{
                        //    drow[10].SetValue = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                        //    drow[11] = "Completed";
                        //}
                        if (!Convert.IsDBNull(drow[i]))
                            sw.Write(drow[i].ToString());
                        if (i < data - 1)
                            sw.Write(seperator);
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error Message");
                throw ex;
            }
        }
        public void Download_File()
        {
            string datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            string LogFolder = _iconfiguration.GetSection("Dremio_Download").GetSection("Log_Path").Value;
            try
            {
                //Declare Variables and provide values
                string fileNamePart = _iconfiguration.GetSection("Dremio_Download").GetSection("FileNamePart").Value;//Datetime will be added to it
                string destinationFolder = _iconfiguration.GetSection("Dremio_Download").GetSection("DestinationFolder").Value;
                string tableName = _iconfiguration.GetSection("Dremio_Download").GetSection("TableName").Value;
                string fileDelimiter = _iconfiguration.GetSection("Dremio_Download").GetSection("FileDelimiter").Value; //You can provide comma or pipe or whatever you like
                string fileExtension = _iconfiguration.GetSection("Dremio_Download").GetSection("FileExtension").Value; //Provide the extension you like such as .txt or .csv
                //Create Connection to SQL Server in which you like to load files
                var Connection = _iconfiguration.GetSection("Dremio_ConnectionString").GetSection("Forgot_Customer").Value;
                OdbcConnection DbConnection = new OdbcConnection(Connection);
                //Read data from table or view to data table
                string query = "Select * From " + tableName;
                OdbcCommand DbCommand = DbConnection.CreateCommand();
                OdbcCommand odbcCommand = new OdbcCommand(query, DbConnection);
                DbConnection.Open();
                DataTable d_table = new DataTable();
                d_table.Load(odbcCommand.ExecuteReader());
                DbConnection.Close();
                //Prepare the file path 
                string FileFullPath = destinationFolder + "\\" + fileNamePart + "_" + datetime + fileExtension;
                StreamWriter sw = null;
                sw = new StreamWriter(FileFullPath, false);
                // Write the Header Row to File
                int ColumnCount = d_table.Columns.Count;
                for (int ic = 0; ic < ColumnCount; ic++)
                {
                    sw.Write(d_table.Columns[ic]);
                    if (ic < ColumnCount - 1)
                    {
                        sw.Write(fileDelimiter);
                    }
                }
                sw.Write(sw.NewLine);
                // Write All Rows to the File
                foreach (DataRow dr in d_table.Rows)
                {
                    for (int ir = 0; ir < ColumnCount; ir++)
                    {
                        if (!Convert.IsDBNull(dr[ir]))
                        {
                            sw.Write(dr[ir].ToString());
                        }
                        if (ir < ColumnCount - 1)
                        {
                            sw.Write(fileDelimiter);
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception exception)
            {
                using (StreamWriter sw = File.CreateText(LogFolder
                    + "\\" + "ErrorLog_" + datetime + ".log"))
                {
                    sw.WriteLine(exception.ToString());
                }
            }
        }
        public void Textupload()
        {
            using (StreamReader sr = new StreamReader(File.Open(@"D:\Tata_Digital\Uploaded_files\Croma_CustomersForgot_Croma_20201214194152.csv", FileMode.Open)))
            {
                using (MySqlConnection txtbaglan = new MySqlConnection(@"server=127.0.0.1;port=3306;userid=root;password=Root@123;database=croma;"))
                {
                    txtbaglan.Open();
                    string line = "";
                    while ((line = sr.ReadLine()) != "")
                    {
                        string[] parts = line.Split(new string[] { "," }, StringSplitOptions.None);
                        string cmdTxt = string.Format("INSERT INTO croma.vw_customer_transition_croma_forget VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}')", parts[0], parts[1], parts[2], parts[3], parts[4], parts[5] = null, parts[6] = null);//", parts[0], parts[1]);
                        using (MySqlCommand cmddd = new MySqlCommand(cmdTxt, txtbaglan))
                        {
                            cmddd.ExecuteNonQuery();
                        }
                    }
                }
            }
        }
        public void Upload_CSVtoMySql()
        {
            try
            {
                string SourceFolder = _iconfiguration.GetSection("upload_Csv_MySql").GetSection("SourceFolder").Value;
                string SourceFileName = _iconfiguration.GetSection("upload_Csv_MySql").GetSection("SourceFileName").Value;
                string TableName = _iconfiguration.GetSection("upload_Csv_MySql").GetSection("TableName").Value;
                string filedelimiter = _iconfiguration.GetSection("upload_Csv_MySql").GetSection("filedelimiter").Value;
                string ArchiveFodler = _iconfiguration.GetSection("upload_Csv_MySql").GetSection("ArchiveFodler").Value;
                MySqlConnection SQLConnection = new MySqlConnection();
                SQLConnection.ConnectionString = _iconfiguration.GetSection("upload_Csv_MySql").GetSection("Connection").Value;
                System.IO.StreamReader SourceFile =
                new System.IO.StreamReader(SourceFolder + SourceFileName);
                string line = "";
                Int32 counter = 0;
                SQLConnection.Open();
                while ((line = SourceFile.ReadLine()) != null)
                {
                    if (counter > 0)
                    {
                        string query = "insert into " + TableName +
                        " Values ('" + line.Replace(filedelimiter, "','") + "')";
                        MySqlCommand cmd = new MySqlCommand(query, SQLConnection);
                        cmd.ExecuteNonQuery();
                    }
                    counter++;
                }
                SourceFile.Close();
                SQLConnection.Close();
                File.Move(SourceFolder + SourceFileName, ArchiveFodler + SourceFileName);
            }
            catch (IOException Exception)
            {
                Console.Write(Exception);
            }
        }
    }
}





