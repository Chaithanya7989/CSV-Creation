﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSV.Model
{
    public enum FileExtension
    {
        CSV = 0,
        TXT = 1,
        gZIP = 2,
        JSON = 3,
    }
}
