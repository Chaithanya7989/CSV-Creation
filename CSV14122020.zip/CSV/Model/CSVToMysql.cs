﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSV.Model
{
  public  class CSVToMysql
    {
        public FileExtension FileExtension { get; set; }
        public string CSVFolderPath { get; set; }
        public string CSVTablePrefix { get; set; }
        public string TableName { get; set; }

        public string TableColums { get; set; }
        public string FilePrefix { get; set; }
        public string Delimiter { get; set; }
        public string ServerName { get; set; }
        public string DBName { get; set; }
        public string UserID { get; set; }
        public string Password { get; set; }
        public string Port { get; set; }
        public string MySQLFilename { get; set; }
        public string MySQLWorkDir { get; set; }
    }
}
